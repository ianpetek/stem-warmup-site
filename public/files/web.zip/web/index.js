const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const sqlite3 = require('sqlite3').verbose();
const path = require("path");
const fs = require("fs");
const cookieParser = require('cookie-parser');

const app = express();
app.use(bodyParser.json());
app.use(cookieParser());;

const db = new sqlite3.Database('./database.db', (err) => {
  if (err) {
    console.error('Could not connect to database', err);
  } else {
    console.log('Connected to SQLite database.');
  }
});

// Create a "users" table if it doesn't exist
db.run(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    isAdmin INTEGER NOT NULL DEFAULT 0
  )
`);

const SECRET_KEY = "PROD HAS DIFFERENT KEY"

function verifyAdminToken(req, res, next) {
  const token = req.cookies.token;
  jwt.verify(token, SECRET_KEY, (err, decoded) => {
    if (err) {
        return res.redirect("/login");
    }
    // Check if decoded token indicates user is admin
    if (!decoded.isAdmin) {
        return res.redirect("/login");
    }
    // Attach user data to request for further use if needed
    req.user = decoded;
    next();
  });
}

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, "index.html"));
});

app.get('/blog/posts', (req, res) => {
    res.sendFile(path.join(__dirname, "blog_data.json"));
})

app.get('/blog/:id', (req, res) => {
  const blogId = parseInt(req.params.id, 10);
  const blogData = JSON.parse(fs.readFileSync("blog_data.json", "utf8"))
  const post = blogData.find((p) => p.id === blogId);

  // If no post is found with this ID, send a 404 response
  if (!post) {
    return res.status(404).send('Blog post not found');
  }

  // Return a minimal HTML page to display the single blog post
  // Styling below matches the look-and-feel from the main blog page
  const html = `
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8" />
    <title>${post.title}</title>
    <style>
      * {
        box-sizing: border-box;
      }
      body {
        margin: 0;
        padding: 0;
        font-family: Arial, sans-serif;
        background-color: #f2f2f2;
      }
      header {
        background-color: #333;
        padding: 20px;
        text-align: center;
      }
      header h1 {
        color: #fff;
        margin: 0;
      }
      .container {
        max-width: 800px;
        margin: 20px auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 8px;
      }
      .post-title {
        margin-top: 0;
        font-size: 1.75rem;
      }
      .post-content {
        line-height: 1.6;
        margin-top: 1rem;
      }
      .back-link {
        display: inline-block;
        margin-top: 20px;
        padding: 8px 12px;
        text-decoration: none;
        color: #fff;
        background-color: #333;
        border-radius: 4px;
      }
      .back-link:hover {
        background-color: #555;
      }
    </style>
  </head>
  <body>
    <header>
      <h1>My Blog</h1>
    </header>
    <div class="container">
      <h2 class="post-title">${post.title}</h2>
      <div class="post-content">${post.content}</div>
      <a class="back-link" href="/">Go Back to Main Blog</a>
    </div>
  </body>
  </html>
  `;

  res.send(html);
});

app.get('/login', (req, res) => {
    res.sendFile(path.join(__dirname, "login.html"));
})

app.post('/login', (req, res) => {
  const { username, password } = req.body;

  // Check if username and password are provided
  if (!username || !password) {
    return res.status(400).json({ message: 'Username and password required' });
  }

  // Find the user in the database
  const query = `SELECT * FROM users WHERE username = ?`;
  db.get(query, [username], async (err, user) => {
    if (err) {
      return res.status(500).json({ message: 'Database error', error: err });
    }

    if (!user) {
      return res.status(400).json({ message: 'Invalid username or password' });
    }

    // Compare the submitted password with the hashed password in DB
    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      return res.status(400).json({ message: 'Invalid username or password' });
    }

    // If password is correct, sign a JWT
    const token = jwt.sign(
      {
        userId: user.id,
        username: user.username,
        isAdmin: !!user.isAdmin // Coerce to boolean
      },
      SECRET_KEY,
      { expiresIn: '1h' }
    );

    return res.json({ message: 'Login successful', token });
  });
});


// verifyAdminToken protects /admin routes from being access by non admins.
app.get('/admin', verifyAdminToken, (req, res) => {
  res.send('<h1>Admin Dashboard</h1><p>You have access because you are an admin. SUSFER{fake_flag_for_testing}</p>');
});

app.post('/admin/createUser', async (req, res) => {
  const { username, password, isAdmin } = req.body;

  // Basic validation
  if (!username || !password) {
    return res.status(400).json({ message: 'Username and password are required' });
  }

  try {
    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insert into the database
    const insertQuery = `
      INSERT INTO users (username, password, isAdmin)
      VALUES (?, ?, ?)
    `;
    db.run(
      insertQuery,
      [username, hashedPassword, isAdmin ? 1 : 0],
      function (err) {
        if (err) {
          return res.status(500).json({ message: 'Failed to create user', error: err });
        }
        return res.json({ message: 'User created successfully', userId: this.lastID });
      }
    );
  } catch (err) {
    return res.status(500).json({ message: 'Error hashing password', error: err });
  }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
