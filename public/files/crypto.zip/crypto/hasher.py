import hashlib
import socket
import threading

def pad(data: bytes) -> bytes:
    while (len(data) % 16 != 0):
        data += b"\x00"

    return data

def sha256_hash(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

HOST = "0.0.0.0"
PORT = 1338

def handle_client(conn, addr):
    with conn:
        print(f"[CLIENT][INFO] Connected by {addr}")

        greeter = "Welcome to our secure, hash-based data storage. You can only access the secured data if you can pass the very secure checks in the program.\n"
        conn.sendall(greeter.encode('utf-8'))

        input_msg = "Enter the first input:"
        conn.sendall(input_msg.encode('utf-8'))
        data1 = conn.recv(1024)
        data1 = data1[:len(data1) - 1]
        if not data1:
            print("[CLIENT][ERROR] No data received for the first input.")
        else:
            print("[CLIENT][INFO] Input 1:", data1)

        input_msg2 = "Enter the second input:"
        conn.sendall(input_msg2.encode('utf-8'))
        data2 = conn.recv(1024)
        data2 = data2[:len(data2) - 1]
        if not data2:
            print("[CLIENT][ERROR] No data received for the first input.")
        else:
            print("[CLIENT][INFO] Input 2:", data2)

        response = "Checking your inputs...\n"
        conn.sendall(response.encode('utf-8'))
        if (data1 != data2 and sha256_hash(pad(data1)) == sha256_hash(pad(data2))):
            with open("flag.txt", "r") as f:
                flag = f.read()
                conn.sendall(flag.encode('utf-8'))
                print("[CLIENT][INFO] Flag successfully retreived.")
        else:
            conn.sendall("It appears you can't access the data after all".encode('utf-8'))

        conn.close()


if __name__ == "__main__":
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.bind((HOST, PORT))
        server_socket.listen(5)
        print(f"[SERVER][INFO] Server listening on {HOST}:{PORT}...")

        while True:
            conn, addr = server_socket.accept()

            client_thread = threading.Thread(
                target=handle_client,
                args=(conn, addr),
                daemon=True
            )
            client_thread.start()

