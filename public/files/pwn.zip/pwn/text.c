#include "stdio.h"
#include "string.h"
#include <ctype.h>

char *howleftthishere = "/bin/sh";

void gadgets() {
    asm("pop rsi; ret;");
    asm("pop rdi; ret;");
    asm("pop rdx; ret;");
    asm("pop rax; ret;");
    asm("syscall");
}

void setup() {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);

    printf("Input the text you want to sPoNgEbObYfY: ");
}

void spongebobyfy(char* str) {
    for (int i = 0; i < strlen(str); i++) {
        if (i % 2 == 0) {
            str[i] = tolower(str[i]);
        } else {
            str[i] = toupper(str[i]);
        }
    }
}

int main() {
    setup();
    char buffer[128];
    memset(buffer, 0, 128);

    fgets(buffer, 512, stdin);
    buffer[127] = '\0';
    spongebobyfy(buffer);

    printf("Your result: %s\n", buffer);

    return 0;
}
